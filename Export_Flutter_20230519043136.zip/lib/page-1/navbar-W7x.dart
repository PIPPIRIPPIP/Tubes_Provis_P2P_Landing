import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // navbarVwt (64:118)
        padding: EdgeInsets.fromLTRB(33.06*fem, 10*fem, 147.55*fem, 10*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff3584ff),
          boxShadow: [
            BoxShadow(
              color: Color(0x4c000000),
              offset: Offset(4*fem, 0*fem),
              blurRadius: 2*fem,
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // igaminghouseP1g (64:120)
              margin: EdgeInsets.fromLTRB(0*fem, 0.35*fem, 74.06*fem, 0*fem),
              width: 26.87*fem,
              height: 23.52*fem,
              child: Image.asset(
                'assets/page-1/images/i-gaming-house-eea.png',
                width: 26.87*fem,
                height: 23.52*fem,
              ),
            ),
            Container(
              // componentgmU (64:123)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 78.55*fem, 0*fem),
              width: 30*fem,
              height: 30*fem,
              child: Image.asset(
                'assets/page-1/images/component.png',
                width: 30*fem,
                height: 30*fem,
              ),
            ),
            Container(
              // iobjecttoolsscrollBy8 (64:121)
              margin: EdgeInsets.fromLTRB(0*fem, 0.14*fem, 0*fem, 0*fem),
              width: 23.91*fem,
              height: 23.62*fem,
              child: Image.asset(
                'assets/page-1/images/i-object-tools-scroll.png',
                width: 23.91*fem,
                height: 23.62*fem,
              ),
            ),
          ],
        ),
      ),
          );
  }
}
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // navbar5xS (63:434)
        padding: EdgeInsets.fromLTRB(25*fem, 7*fem, 10*fem, 8*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff3584ff),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // group62zZc (63:436)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 120*fem, 0*fem),
              padding: EdgeInsets.fromLTRB(0*fem, 5.41*fem, 0*fem, 0*fem),
              height: 47*fem,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // igaminghouseVmG (63:437)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 3.07*fem),
                    width: 26.87*fem,
                    height: 23.52*fem,
                    child: Image.asset(
                      'assets/page-1/images/i-gaming-house-WBg.png',
                      width: 26.87*fem,
                      height: 23.52*fem,
                    ),
                  ),
                  Text(
                    // berandac5C (63:439)
                    'Beranda',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 10*ffem,
                      fontWeight: FontWeight.w600,
                      height: 1.5*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupxuy9958 (3wAQ9rKTsd23md7q2uxuy9)
              margin: EdgeInsets.fromLTRB(0*fem, 2.25*fem, 75*fem, 0*fem),
              width: 36*fem,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    // receivefpA (63:454)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 2.25*fem),
                    width: 29.77*fem,
                    height: 27.5*fem,
                    child: Image.asset(
                      'assets/page-1/images/receive.png',
                      width: 29.77*fem,
                      height: 27.5*fem,
                    ),
                  ),
                  Container(
                    // pinjamaw8 (63:442)
                    width: double.infinity,
                    child: Text(
                      'Pinjam',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 10*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.5*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // tagihanpinjamanX5g (63:445)
              margin: EdgeInsets.fromLTRB(0*fem, 32*fem, 0*fem, 0*fem),
              child: Text(
                'Tagihan & Pinjaman',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 10*ffem,
                  fontWeight: FontWeight.w600,
                  height: 1.5*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}
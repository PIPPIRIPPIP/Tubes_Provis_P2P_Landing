import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // navbar1zW (45:210)
        padding: EdgeInsets.fromLTRB(20.06*fem, 10*fem, 28.84*fem, 10*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          boxShadow: [
            BoxShadow(
              color: Color(0x4c000000),
              offset: Offset(4*fem, 0*fem),
              blurRadius: 2*fem,
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // igaminghousehsL (45:212)
              margin: EdgeInsets.fromLTRB(0*fem, 0.35*fem, 58.06*fem, 0*fem),
              width: 26.87*fem,
              height: 23.52*fem,
              child: Image.asset(
                'assets/page-1/images/i-gaming-house-whG.png',
                width: 26.87*fem,
                height: 23.52*fem,
              ),
            ),
            Container(
              // component1t2 (45:215)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 59.55*fem, 0*fem),
              width: 30*fem,
              height: 30*fem,
              child: Image.asset(
                'assets/page-1/images/component-swL.png',
                width: 30*fem,
                height: 30*fem,
              ),
            ),
            Container(
              // iobjecttoolsscrollvVC (45:213)
              margin: EdgeInsets.fromLTRB(0*fem, 0.14*fem, 59.55*fem, 0*fem),
              width: 23.91*fem,
              height: 23.62*fem,
              child: Image.asset(
                'assets/page-1/images/i-object-tools-scroll-ovn.png',
                width: 23.91*fem,
                height: 23.62*fem,
              ),
            ),
            Container(
              // d8i (45:214)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 62.83*fem, 0.5*fem),
              width: 25*fem,
              height: 21.5*fem,
              child: Image.asset(
                'assets/page-1/images/.png',
                width: 25*fem,
                height: 21.5*fem,
              ),
            ),
            Container(
              // ihumanpersonvNi (45:216)
              margin: EdgeInsets.fromLTRB(0*fem, 0.52*fem, 0*fem, 0*fem),
              width: 19.32*fem,
              height: 20.53*fem,
              child: Image.asset(
                'assets/page-1/images/i-human-person.png',
                width: 19.32*fem,
                height: 20.53*fem,
              ),
            ),
          ],
        ),
      ),
          );
  }
}
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 414;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // navbar1fk (66:186)
        padding: EdgeInsets.fromLTRB(80.06*fem, 7*fem, 81.05*fem, 13*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff3584ff),
          boxShadow: [
            BoxShadow(
              color: Color(0x4c000000),
              offset: Offset(4*fem, 0*fem),
              blurRadius: 2*fem,
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // igaminghousetUe (66:188)
              margin: EdgeInsets.fromLTRB(0*fem, 4.35*fem, 85.06*fem, 0*fem),
              width: 26.87*fem,
              height: 23.52*fem,
              child: Image.asset(
                'assets/page-1/images/i-gaming-house-8Ea.png',
                width: 26.87*fem,
                height: 23.52*fem,
              ),
            ),
            Container(
              // receivezGn (66:212)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 86.05*fem, 0*fem),
              width: 30*fem,
              height: 30*fem,
              child: Image.asset(
                'assets/page-1/images/receive-fXC.png',
                width: 30*fem,
                height: 30*fem,
              ),
            ),
            Container(
              // itimeclockarrowcirclepath6ai (66:210)
              margin: EdgeInsets.fromLTRB(0*fem, 4.14*fem, 0*fem, 0*fem),
              width: 24.9*fem,
              height: 22.72*fem,
              child: Image.asset(
                'assets/page-1/images/i-time-clockarrowcirclepath.png',
                width: 24.9*fem,
                height: 22.72*fem,
              ),
            ),
          ],
        ),
      ),
          );
  }
}
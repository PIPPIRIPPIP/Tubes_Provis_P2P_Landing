import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 1812;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // rosourceqfC (46:87)
        padding: EdgeInsets.fromLTRB(51*fem, 22*fem, 54*fem, 22*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupkcumvge (3wA5qspykrzLsnnzZTkCuM)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 23*fem, 171*fem),
              width: 730*fem,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // resourcee6r (46:85)
                    margin: EdgeInsets.fromLTRB(9*fem, 0*fem, 0*fem, 28*fem),
                    child: Text(
                      'Resource',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 40*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // autogrouptbgb3ug (3wA6BNGWAEx5iPzLanTbgb)
                    margin: EdgeInsets.fromLTRB(9*fem, 0*fem, 0*fem, 14*fem),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // colorpalleteBW6 (46:88)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 62*fem, 0*fem),
                          child: Text(
                            'Color Pallete',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // profilpageW2a (46:90)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 165*fem, 0*fem),
                          child: Text(
                            'Profil Page',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Text(
                          // marketplacecrJ (46:91)
                          'Marketplace',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w700,
                            height: 1.5*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // autogroupnhdqxfG (3wA6MCKTePYdj7XqWzNhDq)
                    margin: EdgeInsets.fromLTRB(9*fem, 0*fem, 0*fem, 115*fem),
                    height: 403*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // autogroupec5uHBk (3wA6VXQv2H4u4Q4TqQEc5u)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 55*fem, 0*fem),
                          width: 137*fem,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // rectangle27QnA (7:188)
                                width: double.infinity,
                                height: 103*fem,
                                decoration: BoxDecoration (
                                  color: Color(0xffbbe1fa),
                                ),
                              ),
                              SizedBox(
                                height: 14*fem,
                              ),
                              Container(
                                // colorhuntpalette1b262c0f4c7532 (1:6)
                                width: 137*fem,
                                height: 121*fem,
                                child: Image.asset(
                                  'assets/page-1/images/color-hunt-palette-1b262c0f4c753282b8bbe1fa-1.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                              SizedBox(
                                height: 14*fem,
                              ),
                              Container(
                                // colorhuntpalette06283d1363df47 (1:13)
                                width: 137*fem,
                                height: 140*fem,
                                child: Image.asset(
                                  'assets/page-1/images/color-hunt-palette-06283d1363df47b5ffdff6ff-1.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // profila4N (46:89)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 62*fem, 0*fem),
                          width: 213*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // image12h8z (20:20)
                                width: 213*fem,
                                height: 105.28*fem,
                                child: Image.asset(
                                  'assets/page-1/images/image-12.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Container(
                                // autogroupr4thRan (3wA6jBgpZXxrN75yEdr4Th)
                                padding: EdgeInsets.fromLTRB(1.16*fem, 0*fem, 0*fem, 0*fem),
                                width: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Container(
                                      // image13ZBC (20:22)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                      width: 211.84*fem,
                                      height: 108.67*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/image-13.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                    Container(
                                      // image14UZ4 (20:24)
                                      width: 211.84*fem,
                                      height: 189.05*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/image-14.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // image8obL (18:3)
                          width: 254*fem,
                          height: 403*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-8.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // topupwhY (46:131)
                    margin: EdgeInsets.fromLTRB(9*fem, 0*fem, 0*fem, 24*fem),
                    child: Text(
                      'TopUp ',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupsnphFy8 (3wA6rRykFTVEz2KrYySnPh)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 46*fem, 0*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // topupBrn (46:150)
                          margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 19*fem, 0*fem),
                          width: 280*fem,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroupkmewibp (3wA7XFCQVJBMUQptkXkmew)
                                width: double.infinity,
                                height: 629*fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // whatsappimage20230404at1913fGA (46:132)
                                      left: 0*fem,
                                      top: 0*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 280*fem,
                                          height: 479*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/whatsapp-image-2023-04-04-at-1913.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // whatsappimage20230404at2125xWA (46:134)
                                      left: 0*fem,
                                      top: 265*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 280*fem,
                                          height: 364*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/whatsapp-image-2023-04-04-at-2125-iEJ.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // whatsappimage20230404at2125GWr (46:133)
                                width: 280*fem,
                                height: 212*fem,
                                child: Image.asset(
                                  'assets/page-1/images/whatsapp-image-2023-04-04-at-2125.png',
                                ),
                              ),
                              Container(
                                // whatsappimage20230404at2126Qsx (46:135)
                                width: 280*fem,
                                height: 84*fem,
                                child: Image.asset(
                                  'assets/page-1/images/whatsapp-image-2023-04-04-at-2126-ts8.png',
                                ),
                              ),
                              Container(
                                // whatsappimage20230404at2126jfL (46:137)
                                width: 280*fem,
                                height: 89*fem,
                                child: Image.asset(
                                  'assets/page-1/images/whatsapp-image-2023-04-04-at-2126-nnS.png',
                                ),
                              ),
                              Container(
                                // whatsappimage20230404at2126g4n (46:136)
                                width: 280*fem,
                                height: 125*fem,
                                child: Image.asset(
                                  'assets/page-1/images/whatsapp-image-2023-04-04-at-2126.png',
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroups6qpD4i (3wA6zquPuodBuioJnvs6QP)
                          width: 385*fem,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // autogroup1ny7MAv (3wA7B1H8XngUJ687RK1nY7)
                                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11*fem),
                                width: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      // image24giz (69:250)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 90*fem),
                                      width: 321*fem,
                                      height: 657*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/image-24.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                    Text(
                                      // logopaymentcce (69:256)
                                      'Logo Payment',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 20*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // autogroupp3kdZGz (3wA75qm4wLY9WVWtBaP3Kd)
                                width: double.infinity,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // image25K1G (69:255)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 41*fem, 0*fem),
                                      width: 119*fem,
                                      height: 101*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/image-25.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                    Container(
                                      // image26qkJ (69:258)
                                      margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 0*fem, 0*fem),
                                      width: 225*fem,
                                      height: 65*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/image-26.png',
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupcic7xa2 (3wA8FoopVnZBfNs7VaCic7)
              margin: EdgeInsets.fromLTRB(0*fem, 47*fem, 93*fem, 0*fem),
              width: 386*fem,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // detailumkmdetailketikakliksala (46:92)
                    constraints: BoxConstraints (
                      maxWidth: 386*fem,
                    ),
                    child: RichText(
                      text: TextSpan(
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 20*ffem,
                          fontWeight: FontWeight.w700,
                          height: 1.5*ffem/fem,
                          color: Color(0xff000000),
                        ),
                        children: [
                          TextSpan(
                            text: 'Detail UMKM \n',
                          ),
                          TextSpan(
                            text: '* detai l ketika klik salah satu umkm di marketplace',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    // autogroupf3pvMka (3wA8NyGYuFTtgtAAtNF3PV)
                    padding: EdgeInsets.fromLTRB(0*fem, 18*fem, 0*fem, 0*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group34tkW (46:93)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 67*fem),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // whatsappimage20230404at8421SGE (45:60)
                                width: 370*fem,
                                height: 397.88*fem,
                                child: Image.asset(
                                  'assets/page-1/images/whatsapp-image-2023-04-04-at-842-1.png',
                                ),
                              ),
                              Container(
                                // whatsappimage20230404at8422ZLr (45:61)
                                width: 370*fem,
                                height: 557.12*fem,
                                child: Image.asset(
                                  'assets/page-1/images/whatsapp-image-2023-04-04-at-842-2.png',
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // image276Ln (69:378)
                          margin: EdgeInsets.fromLTRB(15*fem, 0*fem, 0*fem, 0*fem),
                          width: 357*fem,
                          height: 794*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-27.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupl7u9Rdx (3wA8aTwQ4aN6ZrcCHTL7u9)
              margin: EdgeInsets.fromLTRB(0*fem, 95*fem, 0*fem, 0*fem),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // image23xNz (38:25)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 467*fem),
                    width: 475*fem,
                    height: 795*fem,
                    child: Image.asset(
                      'assets/page-1/images/image-23.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  Container(
                    // image9V82 (63:666)
                    margin: EdgeInsets.fromLTRB(26*fem, 0*fem, 0*fem, 0*fem),
                    width: 275*fem,
                    height: 595*fem,
                    child: Image.asset(
                      'assets/page-1/images/image-9.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}